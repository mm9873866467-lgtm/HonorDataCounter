package com.example.honordatacounter

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var mobileValue: TextView
    private lateinit var wifiValue: TextView
    private lateinit var totalValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshStats()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStats()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 32)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
            gravity = Gravity.TOP
        }
        fun heading(text: String, size: Float): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 14, 0, 10)
        }
        layout.addView(heading("عداد البيانات", 28f))
        layout.addView(heading("استهلاك نقل البيانات المسجّل من أندرويد", 15f))
        status = heading("حالة الصلاحية: جارٍ الفحص", 14f)
        layout.addView(status)
        layout.addView(heading("استهلاك الشريحة — منذ بداية الشهر", 17f))
        mobileValue = heading("غير متاح بعد", 23f)
        layout.addView(mobileValue)
        layout.addView(heading("استهلاك الواي فاي — منذ بداية الشهر", 17f))
        wifiValue = heading("غير متاح بعد", 23f)
        layout.addView(wifiValue)
        layout.addView(heading("الإجمالي الظاهر", 17f))
        totalValue = heading("—", 23f)
        layout.addView(totalValue)
        val refresh = Button(this).apply {
            text = "تحديث الإحصاءات"
            setOnClickListener { refreshStats() }
        }
        layout.addView(refresh)
        val permission = Button(this).apply {
            text = "منح صلاحية الوصول إلى إحصاءات الاستخدام"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        layout.addView(permission)
        layout.addView(heading(
            "مهم: هذه نسخة أولية. يجب منح صلاحية الوصول للاستخدام من إعدادات أندرويد. " +
            "قد تختلف النتائج حسب إصدار HONOR/أندرويد والشريحة، ولا تُعدّ فاتورة شركة الاتصالات.",
            13f
        ))
        setContentView(layout)
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun monthStartMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun deviceBytes(networkType: Int): Long? {
        return try {
            val manager = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val stats = manager.querySummaryForDevice(
                networkType,
                null,
                monthStartMillis(),
                System.currentTimeMillis()
            )
            stats.rxBytes + stats.txBytes
        } catch (_: SecurityException) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun formatBytes(bytes: Long?): String {
        if (bytes == null) return "غير متاح — تحقق من الصلاحية أو دعم الجهاز"
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        val mb = bytes / (1024.0 * 1024.0)
        return if (gb >= 1.0) String.format("%.2f جيجابايت", gb)
        else String.format("%.1f ميغابايت", mb)
    }

    private fun refreshStats() {
        if (!hasUsageAccess()) {
            status.text = "حالة الصلاحية: لم تُمنح بعد"
            mobileValue.text = "—"
            wifiValue.text = "—"
            totalValue.text = "—"
            return
        }
        status.text = "آخر تحديث: " + DateFormat.getTimeInstance().format(Date())
        val mobile = deviceBytes(ConnectivityManager.TYPE_MOBILE)
        val wifi = deviceBytes(ConnectivityManager.TYPE_WIFI)
        mobileValue.text = formatBytes(mobile)
        wifiValue.text = formatBytes(wifi)
        totalValue.text = if (mobile != null && wifi != null) formatBytes(mobile + wifi) else "غير مكتمل"
    }
}
